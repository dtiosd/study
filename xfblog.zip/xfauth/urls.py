from django.urls import path
from . import views

app_name = 'xfauth'

urlpatterns = [
    path('login',views.xflogin,name='login'),
    path('logout',views.xflogout,name='logout'),
    path('register',views.register,name='register'),
    path('captcha',views.send_email_captcha,name='email_captcha'),
]